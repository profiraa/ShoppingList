const item = document.getElementById('item');
const addButton = document.getElementById('add');
const table = document.getElementById('food');

//clasa PRODUS GENERAL  
function Cumparat(produs, status) {
    this.produs = produs;
    this.status = status;
}

//ADAUGAREA PRODUSULUI CU TASTA 'ENTER'
item.addEventListener('keyup', function(event) {
    if(event.keyCode === 13){
        event.preventDefault();
        addButton.click();
    }
});

//ADAUGAREA IN TABEL A NOULUI PRODUS
addButton.addEventListener('click', addItem);
const output2 = `<button class='markBtn'>Mark as bought</button>`;

function addItem(){
    const x = item.value;
    const y = output2;
    const cumparat = new Cumparat(x, y);
    console.log(table.innerHTML);

    const output = `<tr class='row'>
                        <td class='row1'>${cumparat.produs}</td>
                        <td class='row2'>${cumparat.status}</td>
                    </tr>`
    console.log(output);
table.innerHTML = table.innerHTML + output;
}

//TAIEREA CU O LINIE A PRODUSULUI
table.addEventListener('click', taiat);

function taiat(e){
    const x = e.target.classList.contains('markBtn');
    console.log(x);
    const y = e.target.parentNode.previousElementSibling;
    console.log(y);
if(x){
   y.style.textDecoration = 'line-through'; 
}
    console.log(y);
}

//SORTARE ALFABETICA (ASC)
const btnSortAsc = document.getElementById('sortAsc');
btnSortAsc.addEventListener('click', sortTable);

function sortTable() {
    var table, rows, switching, i, x, y, shouldSwitch;
    table = document.getElementById("food");
    switching = true;
    while (switching) {
      switching = false;
      rows = table.rows;
      for (i = 1; i < (rows.length + 1); i++) {
        shouldSwitch = false;
        x = rows[i].getElementsByTagName("td")[0];
        y = rows[i + 1].getElementsByTagName("td")[0];
        if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
          shouldSwitch = true;
          break;
        }
      }
      if (shouldSwitch) {
        rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
        switching = true;
      }
    }
  }

//SORTARE ALFABETICA (DESC)
const btnSortDesc = document.getElementById('sortDesc');
btnSortDesc.addEventListener('click', sortTable2);

function sortTable2() {
    var table, rows, switching, i, x, y, shouldSwitch;
    table = document.getElementById("food");
    switching = true;
    while (switching) {
      switching = false;
      rows = table.rows;
      for (i = 1; i < (rows.length + 1); i++) {
        shouldSwitch = false;
        x = rows[i].getElementsByTagName("td")[0];
        y = rows[i + 1].getElementsByTagName("td")[0];
        if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
          shouldSwitch = true;
          break;
        }
      }
      if (shouldSwitch) {
        rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
        switching = true;
      }
    }
  }